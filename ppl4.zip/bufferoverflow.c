#include<stdio.h>
int main(){
 	int array[10];
	int i;
	for(i=0; i<10000; i++){
		array[i];
	}
	return 0;
}
